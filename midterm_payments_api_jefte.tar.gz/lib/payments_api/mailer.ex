defmodule PaymentsApi.Mailer do
  use Swoosh.Mailer, otp_app: :payments_api
end
